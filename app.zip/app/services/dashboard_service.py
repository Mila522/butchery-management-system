from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.product import Product
from app.models.category import Category
from app.models.daily_analytics import DailyAnalytics


def get_dashboard(db: Session):
    total_products = db.query(Product).count()

    active_products = (
        db.query(Product)
        .filter(Product.active == True)
        .count()
    )

    total_stock = (
        db.query(func.coalesce(func.sum(Product.current_stock), 0))
        .scalar()
    )

    stock_value = (
        db.query(func.coalesce(func.sum(DailyAnalytics.stock_value), 0))
        .scalar()
    )

    return {
        "total_products": total_products,
        "active_products": active_products,
        "total_stock": float(total_stock),
        "stock_value": float(stock_value),
    }


def get_category_stock(db: Session):

    data = (
        db.query(
            Category.name.label("category"),
            func.coalesce(func.sum(Product.current_stock), 0).label("stock"),
        )
        .join(Product)
        .group_by(Category.name)
        .order_by(Category.name)
        .all()
    )

    return [
        {
            "category": row.category,
            "stock": float(row.stock),
        }
        for row in data
    ]


def get_inventory_distribution(db: Session):

    data = (
        db.query(
            Category.name.label("name"),
            func.coalesce(func.sum(Product.current_stock), 0).label("value"),
        )
        .join(Product)
        .group_by(Category.name)
        .all()
    )

    return [
        {
            "name": row.name,
            "value": float(row.value),
        }
        for row in data
    ]

def get_stock_trend(db: Session):

    rows = (
        db.query(
            DailyAnalytics.analytics_date,
            func.coalesce(func.sum(DailyAnalytics.remaining_stock), 0)
        )
        .group_by(DailyAnalytics.analytics_date)
        .order_by(DailyAnalytics.analytics_date)
        .limit(7)
        .all()
    )

    return [
        {
            "date": row.analytics_date.strftime("%d %b"),
            "stock": float(row[1]),
        }
        for row in rows
    ]

def get_low_stock(db: Session):

    products = (
        db.query(Product)
        .filter(
            Product.active == True,
            Product.current_stock <= Product.minimum_stock
        )
        .order_by(Product.current_stock.asc())
        .limit(10)
        .all()
    )

    return [
        {
            "id": p.id,
            "name": p.name,
            "current_stock": float(p.current_stock),
            "minimum_stock": float(p.minimum_stock),
        }
        for p in products
    ]