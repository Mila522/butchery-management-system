from datetime import date

from sqlalchemy.orm import Session

from app.models.daily_stock import DailyStock
from app.models.product import Product
from app.models.product_daily_status import ProductDailyStatus
from decimal import Decimal
from datetime import date

from app.models.daily_analytics import DailyAnalytics


def update_daily_stock(
    db,
    product,
    received=0,
    damaged=0,
):
    today = date.today()

    snapshot = (
        db.query(DailyStock)
        .filter(
            
            
            DailyStock.product_id == product.id,
            DailyStock.stock_date == today,
        )
        .first()
    )

    if snapshot:
        snapshot.received_today += received
        snapshot.damaged_today += damaged

        snapshot.closing_stock = product.current_stock

    else:

        snapshot = DailyStock(
            product_id=product.id,
            stock_date=today,
            opening_stock=product.current_stock,
            received_today=received,
            damaged_today=damaged,
            closing_stock=product.current_stock,
            notes="Auto-generated",
        )

        db.add(snapshot)

def update_daily_analytics(
    db,
    product,
):
    today = date.today()

    stock = (
        db.query(DailyStock)
        .filter(
            DailyStock.product_id == product.id,
            DailyStock.stock_date == today,
        )
        .first()
    )

    if not stock:
        return

    analytics = (
        db.query(DailyAnalytics)
        .filter(
            DailyAnalytics.product_id == product.id,
            DailyAnalytics.analytics_date == today,
        )
        .first()
    )

    estimated_sold = (
        stock.opening_stock
        + stock.received_today
        - stock.closing_stock
        - stock.damaged_today
    )

    if estimated_sold < 0:
        estimated_sold = Decimal("0")

    revenue = estimated_sold * product.selling_price

    cost = estimated_sold * product.purchase_price

    gross_profit = revenue - cost

    damage_loss = (
        stock.damaged_today
        * product.purchase_price
    )

    stock_value = (
        stock.closing_stock
        * product.purchase_price
    )

    if analytics:

        analytics.estimated_sold = estimated_sold
        analytics.actual_sold = Decimal("0")
        analytics.remaining_stock = stock.closing_stock
        analytics.revenue = revenue
        analytics.cost = cost
        analytics.gross_profit = gross_profit
        analytics.damage_loss = damage_loss
        analytics.stock_value = stock_value

    else:

        analytics = DailyAnalytics(

            analytics_date=today,

            product_id=product.id,

            estimated_sold=estimated_sold,

            actual_sold=Decimal("0"),

            remaining_stock=stock.closing_stock,

            revenue=revenue,

            cost=cost,

            gross_profit=gross_profit,

            damage_loss=damage_loss,

            stock_value=stock_value,

        )

        db.add(analytics)


def update_product_status(
    db: Session,
    product: Product,
    *,
    delivery=False,
    damage=False,
    adjustment=False,
    closing=False,
):
    today = date.today()

    status = (
        db.query(ProductDailyStatus)
        .filter(
            ProductDailyStatus.product_id == product.id,
            ProductDailyStatus.record_date == today,
        )
        .first()
    )

    if not status:

        status = ProductDailyStatus(
            product_id=product.id,
            record_date=today,
            delivery_recorded=False,
            damage_recorded=False,
            adjustment_recorded=False,
            closing_stock_recorded=False,
        )

        db.add(status)

    if delivery:
        status.delivery_recorded = True

    if damage:
        status.damage_recorded = True

    if adjustment:
        status.adjustment_recorded = True

    if closing:
        status.closing_stock_recorded = True