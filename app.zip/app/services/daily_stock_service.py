from datetime import date

from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.models.product import Product
from app.models.daily_stock import DailyStock

from app.schemas.daily_stock import ClosingStockRequest


def get_today_stock(db: Session):

    today = date.today()

    products = db.query(Product).filter(Product.active == True).all()

    results = []

    for product in products:

        stock = (
            db.query(DailyStock)
            .filter(
                DailyStock.product_id == product.id,
                DailyStock.stock_date == today,
            )
            .first()
        )

        if not stock:

            stock = DailyStock(
                product_id=product.id,
                stock_date=today,
                opening_stock=product.current_stock,
                received_today=0,
                damaged_today=0,
                closing_stock=product.current_stock,
            )

            db.add(stock)

            db.commit()

            db.refresh(stock)

        results.append({

            "id": stock.id,

            "product_id": product.id,

            "product_name": product.name,

            "stock_date": stock.stock_date,

            "opening_stock": stock.opening_stock,

            "received_today": stock.received_today,

            "damaged_today": stock.damaged_today,

            "closing_stock": stock.closing_stock,

            "notes": stock.notes,

            "created_at": stock.created_at,

        })

    return results


def save_closing_stock(
    db: Session,
    payload: ClosingStockRequest,
):

    today = date.today()

    for item in payload.items:

        stock = (
            db.query(DailyStock)
            .filter(
                DailyStock.product_id == item.product_id,
                DailyStock.stock_date == today,
            )
            .first()
        )

        if not stock:
            raise HTTPException(
                status_code=404,
                detail=f"Daily stock not found for product {item.product_id}",
            )

        stock.closing_stock = item.closing_stock

        product = (
            db.query(Product)
            .filter(Product.id == item.product_id)
            .first()
        )

        product.current_stock = item.closing_stock

    db.commit()

    return {

        "message": "Closing stock saved successfully."

    }